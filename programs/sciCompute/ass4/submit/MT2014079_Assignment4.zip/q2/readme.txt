Procedure to run
================
	$ make
	$ ./q2