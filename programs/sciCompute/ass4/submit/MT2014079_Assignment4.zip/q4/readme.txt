Procedure to run
================
	$ make
	$ ./q4