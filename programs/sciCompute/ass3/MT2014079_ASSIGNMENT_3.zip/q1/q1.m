A = [2 3 2;
	10 3 4;
	3 6 1];
%A = [0.5 0.5 0.5; 3 0 0; 1 1 -3];
[EigenVector,EigenValue] = eigs(A)
