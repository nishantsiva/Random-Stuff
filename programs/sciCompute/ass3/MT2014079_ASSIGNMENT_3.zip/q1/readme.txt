Procedure to run
================
	$ make
	$ ./q1
	$ matlab -nojvm -nodesktop -r "q1;quit"