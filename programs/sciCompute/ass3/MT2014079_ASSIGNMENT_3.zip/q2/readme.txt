Procedure to run
================
	$ matlab -nojvm -nodesktop -r "q2;quit"