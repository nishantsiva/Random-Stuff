Procedure to run
================
	$ make
	$ ./q3