Procedure to run
================
	$ make
	$ ./q5
	$ matlab -nojvm -nodesktop -r "q5;quit"