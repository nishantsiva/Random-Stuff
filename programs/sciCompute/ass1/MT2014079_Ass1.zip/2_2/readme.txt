ASSIGNMENT 1 QUESTION 2.2 PAGE NO 100
======================================


Procedure To Run
================
	$ matlab -nojvm -nodesktop -r "prog;quit"
	
Note : Assumed that matlab executable without specifying entire path.


Output Observed
===============

	Solution to first system of equations:
	
	X1 =

		-7.0000
		4.0000
		-0.0000
	
	Solution to Second system of equations:
	
	X2 =

		-1
		1
		-1
	
	Solution using Sherman Morrison Formula

	ans =

		3.0000
		0.3333
		2.3333
