Procedure To Run
================
	$ matlab -nojvm -nodesktop -r "quest2;quit"
	
Note : Assumed that matlab executable without specifying entire path.

