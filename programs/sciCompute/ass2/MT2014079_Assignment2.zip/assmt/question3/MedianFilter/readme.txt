Procedure To Run
================
	$ make
	$ ./medianFilt_linear [input file] [half width(default = 3)]
	$ ./medianFilt_parallel [input file] [half width(default = 3)]
	$ make clean
