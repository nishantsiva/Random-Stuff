Procedure To Run
================
	$ make
	$ ./imageWarp_linear [input file]
	$ ./imageWarp_parallel [input file]
	$ make clean
