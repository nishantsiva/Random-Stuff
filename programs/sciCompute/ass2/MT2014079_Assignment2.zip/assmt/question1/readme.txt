Procedure To Run
================
	$ matlab -nojvm -nodesktop -r "quest1;quit"
	
Note : Assumed that matlab executable without specifying entire path.

