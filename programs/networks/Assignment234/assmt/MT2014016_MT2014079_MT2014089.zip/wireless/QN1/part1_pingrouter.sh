#!/bin/bash

ping 192.168.14.79
