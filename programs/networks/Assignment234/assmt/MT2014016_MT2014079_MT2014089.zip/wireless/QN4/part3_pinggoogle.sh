#!/bin/bash

route add default gw 192.168.14.79        
ping www.google.com
