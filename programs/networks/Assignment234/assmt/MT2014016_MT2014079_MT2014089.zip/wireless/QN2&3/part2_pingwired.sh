#!/bin/bash

route add default gw 192.168.14.79        
ping 10.100.100.89                      
