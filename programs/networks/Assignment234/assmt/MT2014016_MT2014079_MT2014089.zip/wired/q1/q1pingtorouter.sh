#!/bin/bash
 arp
ping 10.100.100.79

