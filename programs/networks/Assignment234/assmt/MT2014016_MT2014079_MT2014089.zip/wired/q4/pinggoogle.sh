
#!/bin/bash


route add default gw 10.100.100.79
ping google.com
