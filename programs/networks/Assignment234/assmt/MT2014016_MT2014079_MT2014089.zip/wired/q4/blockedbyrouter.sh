
#!/bin/bash

ping 10.100.100.79
