sudo iptables -D INPUT -s 192.168.14.16 -j DROP
